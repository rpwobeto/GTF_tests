﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesafioGFT3
{

    public class COFINS : Imposto
    {
        public double CalcularImposto(double valor)
        {
            double imposto = 0;

            if (17000 < valor)
            {
                imposto = 0.08;
            }

            return valor * imposto;
        }
    }
}
