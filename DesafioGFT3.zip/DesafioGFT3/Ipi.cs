﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesafioGFT3
{
    public class IPI : Imposto
    {
        public double CalcularImposto(double valor)
        {
            double imposto;

            if (25000 > valor)
            {
                imposto = 0.05;
            }
            else
            {
                imposto = 0.10;
            }

            return valor * imposto;
        }
    }
}
