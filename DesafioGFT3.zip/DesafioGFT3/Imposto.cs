﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesafioGFT3
{
    public interface Imposto
    {
        double CalcularImposto(double valor);
    }
}
