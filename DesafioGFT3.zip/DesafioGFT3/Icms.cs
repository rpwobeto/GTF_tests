﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesafioGFT3
{
    public class ICMS : Imposto
    {
        public double CalcularImposto(double valor)
        {
            double imposto = 0.3;

            return valor * imposto;
        }
    }
}
